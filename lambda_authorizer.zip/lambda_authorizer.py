import jwt

SECRET = "secret_api_tutorial"

def lambda_handler(event, context):
    try:
        auth_token = event.get('authorizationToken')
        if not auth_token:
            print("Error: No authorization token provided")
            return generatePolicy("user", "Deny", event.get("methodArn"), "Unauthorized: No token provided")

        user_details = decode_auth_token(auth_token)

        if user_details.get('Name') == "Chinmay" and user_details.get('Role') == "api_user":
            print('Authorized JWT Token')
            return generatePolicy('user', 'Allow', event['methodArn'], "Authorized : Valid JWT Token")

    except jwt.ExpiredSignatureError:
        print("Error: Token has expired")
        return generatePolicy("user", "Deny", event.get("methodArn"), "Error: Token has expired")

    except jwt.InvalidTokenError:
        print("Error: Invalid token")
        return generatePolicy("user", "Deny", event.get("methodArn"), "Error: Invalid JWT Token")

    except Exception as e:
        print(f"Lambda Error: {str(e)}")  # Log exact error
        return generatePolicy("user", "Deny", event.get("methodArn"), f"Lambda Error: {str(e)}")

def generatePolicy(principalId, effect, resource, message):
    authResponse = {
        'principalId': principalId,
        'policyDocument': {
            'Version': '2012-10-17',
            'Statement': [{
                'Action': 'execute-api:Invoke',
                'Effect': effect,
                'Resource': resource
            }]
        },
        "context": {
            "errorMessage": message
        }
    }
    return authResponse

def decode_auth_token(auth_token: str):
    auth_token = auth_token.replace('Bearer ', '')
    return jwt.decode(jwt=auth_token, key=SECRET, algorithms=["HS256"], options={"verify_signature": False, "verify_exp": True})